# Paper 1 reproducibility code

See submission/jom/Reproducibility_Guide.md for environment, data access, and saved-evidence versus raw-signal reproduction boundaries.

Install with python -m pip install -e ".[dev,publication]" then run python scripts/audit_jom_evidence.py --output tmp/audit.json.

The bundle excludes legacy JEET document-package tests, raw/processed signal data, private author contact information and Papers 2-4. Original value CSV/gzip files retain reveal hashes. Exported text metadata has workstation roots removed.
